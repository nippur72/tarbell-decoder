# CONTENT OF THE WAV FILES

- TBASIC.wav is the first take by Jonathan Haddox from the tape #1.
Quality: low volume.

- TBASIC2.wav is the second take from tape #1. Quality: very good.
The dedecoder decodes it with 1 error bit.

- TBASIC2X.wav third take from tape #1, contains several recordings
of the same tape. Quality: audio is saturated

- Orig_TBASIC.wav is 4th take from tape #1. Quality: fair, not as
good as the second take.

- 4-56_TBASIC.wav first take from tape #2. Quality fair.

# SOURCES

- TAPE #1 is labeled "T.BASIC 15.4  0100 5900" "9-13-81" 
"COPYRIGHT 1981 TARBELL ELECTRONICS"

- TAPE #2 is labeled  "4-56 TBASIC" perhaps another copy, or modified copy.

